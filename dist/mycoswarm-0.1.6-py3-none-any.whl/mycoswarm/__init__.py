"""mycoSwarm — Distributed AI framework."""
__version__ = "0.1.6"
